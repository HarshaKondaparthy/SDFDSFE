package threeOne;

public class ReplaceFunction {

	public ReplaceFunction() {
		
	}
	public void replace(String obj1){
		for(int i=0;i<obj1.length();i=i+2){
			
				obj1=obj1.substring(0,i)+"#"+obj1.substring(i+1, obj1.length());
				
		}
		System.out.println(obj1);
	}
}
