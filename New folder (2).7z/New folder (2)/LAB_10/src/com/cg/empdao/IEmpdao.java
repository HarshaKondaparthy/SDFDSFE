package com.cg.empdao;

import com.cg.exception.EmployeeException;
import com.cg.lab10.Employee;

public interface IEmpdao {
	public Employee addEmployee(Employee employee)throws EmployeeException;
}
