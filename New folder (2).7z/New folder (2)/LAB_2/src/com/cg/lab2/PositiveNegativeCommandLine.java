package com.cg.lab2;

import java.util.Scanner;

public class PositiveNegativeCommandLine {

	public static void main(String[] args) {
		
		/*String result;
		Scanner num = new Scanner(System.in);
		System.out.println("Enter the number:");
		int  number = num.nextInt();
		result = (number >=0)? "Positive":"Negative";
		System.out.println("Number is "+ result);
		*/
		
		int num;
		num = Integer.parseInt(args[0]);
		
		if(num > 0)
		System.out.println("Number is positive");
		else
		System.out.println("Number is negative");
	
	}
	
}
