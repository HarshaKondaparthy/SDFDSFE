package com.cg.lab6_1;

public class PersonMain{
	public static void main(String args[])
	{
	
		System.out.println("personDetails");
		System.out.println("----------------");
		PersonDetails p1=new PersonDetails();
		p1.setFirstName("");
		p1.setLastName("");
		p1.getFirstName();
		p1.getLastName();
		
	
	}

}
